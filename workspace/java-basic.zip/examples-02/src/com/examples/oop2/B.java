package com.examples.oop2;

public class B {

}
