package com.examples.oop1; // 패키지 선언문 : 이 클래스가 어떤 패키지에 포함되는지 선언

public class A {

}
