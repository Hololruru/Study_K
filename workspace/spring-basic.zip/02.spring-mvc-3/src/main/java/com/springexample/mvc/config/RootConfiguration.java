package com.springexample.mvc.config;

import org.springframework.beans.factory.annotation.Configurable;

@Configurable
public class RootConfiguration {

}
