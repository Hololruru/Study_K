package com.springexample.springioc;

public interface MessageService {

	String getMessage();
	
	
}